synthetic data evaluation from basin models in figures 2, 3 and 4

 to run: type and enter 
 prog1_SyntheticData
 prog2_DataInversion


 distances in km
 density in g/cm3
